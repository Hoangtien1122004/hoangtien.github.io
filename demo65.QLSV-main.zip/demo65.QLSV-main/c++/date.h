typedef struct
{
	int ngay,thang,nam;
} Date;

void nhapNgay(Date *d);
void inNgay(Date d);//date.h
